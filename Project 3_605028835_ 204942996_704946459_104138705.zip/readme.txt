Since all of us worked on the project we are submitting 4 python files.

--------------------------------------------------------------------------
Project3_q1toq29.ipynb answers all questions from 1 through 29.           |
Project3_q36toq29.ipynb answers all questions from 36 through 39.         |
--------------------------------------------------------------------------
Project3_q1toq39.ipynb answers all questions from 1 through 39.           |
--------------------------------------------------------------------------
Project3_q1toq33.ipynb answers all questions from 1 through 33.           |
--------------------------------------------------------------------------


For report questions 24-29 we used results from Project3_q1toq33.ipynb.
For report question 22 we used results from Project3_q1toq29.ipynb
For all remaining questionswe used results from Project3_q1toq39.ipynb.
